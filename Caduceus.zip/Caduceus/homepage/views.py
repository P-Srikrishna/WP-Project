from django.shortcuts import render, HttpResponse


# Create your views here.
def homepage(request):
    context = {
        "Caduceus": "Caduceus"
    }
    return render(request, "Homepage.html", context)

def consultation(request):
    return HttpResponse("This is our Consultation page")

def counselling(request):
    return HttpResponse("This is our Counselling page")

def elder_care(request):
    return HttpResponse("This is our Elder-Care page")

def nursing(request):
    return HttpResponse("This is our Nursing page")
